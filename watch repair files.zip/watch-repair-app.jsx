import { useState, useEffect, useRef } from "react";

const SUPABASE_URL = "https://jyvsokbmewsuddwgnosw.supabase.co";
const SUPABASE_KEY = "sb_publishable_C4qVSQ24r9edrh5lmEZV7g_mAGZm7j_";
const APP_URL = "https://vitejs-vite-duplicat-1yut.bolt.host";
// Railway server URL - update this after deploying to Railway
const SERVER_URL = "https://your-server.railway.app";

async function sbFetch(path, options = {}) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
    ...options,
    headers: {
      "apikey": SUPABASE_KEY,
      "Authorization": `Bearer ${SUPABASE_KEY}`,
      "Content-Type": "application/json",
      "Prefer": options.prefer || "return=representation",
      ...(options.headers || {}),
    },
  });
  if (!res.ok) { const err = await res.text(); throw new Error(err); }
  const text = await res.text();
  return text ? JSON.parse(text) : [];
}

const STATUS_CONFIG = {
  "Go Ahead":             { color: "#3B82F6", bg: "#EFF6FF" },
  "Not Going":            { color: "#EF4444", bg: "#FEF2F2" },
  "Collected":            { color: "#6B7280", bg: "#F9FAFB" },
  "In Progress":          { color: "#8B5CF6", bg: "#F5F3FF" },
  "Awaiting Parts":       { color: "#F59E0B", bg: "#FFFBEB" },
  "Ready for Collection": { color: "#10B981", bg: "#ECFDF5" },
};
const ALL_STATUSES = Object.keys(STATUS_CONFIG);

function StatusBadge({ status }) {
  const cfg = STATUS_CONFIG[status] || { color: "#6B7280", bg: "#F9FAFB" };
  return (
    <span style={{ background: cfg.bg, color: cfg.color, border: `1px solid ${cfg.color}40`, borderRadius: 20, padding: "3px 12px", fontSize: 12, fontWeight: 600, letterSpacing: "0.02em", whiteSpace: "nowrap" }}>{status}</span>
  );
}

function QRCode({ id, size = 120 }) {
  const url = `${APP_URL}?repair=${encodeURIComponent(id)}`;
  const qrSrc = `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(url)}&bgcolor=ffffff&color=1a1a2e&margin=4`;
  return <img src={qrSrc} alt={`QR for ${id}`} width={size} height={size} style={{ borderRadius: 6, border: "1px solid #e5e7eb" }} />;
}

function printTicket(repair) {
  const url = `${APP_URL}?repair=${encodeURIComponent(repair.id)}`;
  const qrLarge = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(url)}&bgcolor=ffffff&color=1a1a2e&margin=4`;
  const win = window.open("", "_blank");
  const id = repair.id || "";
  const name = (repair.customer_name || "—").replace(/</g,"&lt;").replace(/>/g,"&gt;");
  const phone = (repair.phone || "—").replace(/</g,"&lt;");
  const brand = (repair.watch_brand || "—").replace(/</g,"&lt;");
  const team = (repair.team_member || "—").replace(/</g,"&lt;");
  const dateIn = repair.received_date || "—";
  const estReady = repair.estimated_ready || "TBC";
  const quote = repair.quote != null ? "$" + repair.quote : "TBC";
  const issue = repair.issue ? repair.issue.replace(/</g,"&lt;").replace(/>/g,"&gt;") : "";
  win.document.write(`<!DOCTYPE html><html><head><title>Ticket ${id}</title><style>
    * { margin:0; padding:0; box-sizing:border-box; } body { font-family: Georgia, serif; }
    .lbl { font-size:10px; letter-spacing:0.08em; text-transform:uppercase; margin-bottom:3px; color:#9ca3af; }
    .val { font-size:14px; color:#111827; }
    .p2 { background:#fff; padding:24px; min-height:100vh; display:flex; flex-direction:column; }
    .p2-hdr { text-align:center; border-bottom:2px solid #1a1a2e; padding-bottom:14px; margin-bottom:18px; }
    .p2-shop { font-size:20px; font-weight:bold; letter-spacing:0.08em; color:#1a1a2e; }
    .qrbox { display:flex; align-items:center; gap:16px; border:1.5px dashed #d1d5db; border-radius:10px; padding:14px; margin:16px 0; }
    </style></head><body>
    <div class="p2">
      <div class="p2-hdr"><div class="p2-shop">&#x231A; CHRONO REPAIR STUDIO</div></div>
      <div style="font-size:22px; font-weight:bold; text-align:center;">${id}</div>
      <div style="margin:20px 0; display:grid; grid-template-columns:1fr 1fr; gap:14px;">
        <div><div class="lbl">Customer</div><div class="val" style="font-weight:bold;">${name}</div></div>
        <div><div class="lbl">Watch</div><div class="val">${brand}</div></div>
      </div>
      <div class="qrbox">
        <img src="${qrLarge}" width="110" height="110" style="border-radius:6px;" />
        <div style="font-size:11px; color:#6b7280;">Scan this QR code anytime to check your watch status &mdash; no app needed!</div>
      </div>
      <div style="margin-top:auto; text-align:center; font-size:11px; color:#9ca3af;">Please keep this receipt.<br/>Questions? Call us on 03 9123 4567</div>
    </div>
    <script>window.onload=function(){setTimeout(function(){window.print();},700);}<\/script>
    </body></html>`);
  win.document.close();
}

function QuoteModalForm({ repair, onSend, onClose, inputStyle }) {
  const [quote, setQuote] = useState(repair?.quote || "");
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);

  async function handleSend() {
    if (!quote) return alert("Please enter a quote amount");
    setSending(true);
    await onSend(repair.id, quote, message);
    setSending(false);
  }

  const previewMsg = `Hi ${repair?.customer_name || "there"}, your ${repair?.watch_brand || "watch"} repair quote from Chrono Repair Studio is $${quote || "___"}.${message ? "\n\n" + message : ""}\n\nReply YES to go ahead or NO to decline.`;

  return (
    <div>
      <div style={{ marginBottom:16 }}>
        <label style={{ fontSize:11, color:"#ffffff40", letterSpacing:"0.07em", display:"block", marginBottom:6 }}>QUOTE AMOUNT ($)</label>
        <input type="number" value={quote} onChange={e => setQuote(e.target.value)} placeholder="e.g. 250" style={{ ...inputStyle, fontSize:20, fontWeight:700 }} />
      </div>
      <div style={{ marginBottom:20 }}>
        <label style={{ fontSize:11, color:"#ffffff40", letterSpacing:"0.07em", display:"block", marginBottom:6 }}>EXTRA MESSAGE (optional)</label>
        <textarea value={message} onChange={e => setMessage(e.target.value)} placeholder="e.g. The movement needs replacing, parts are in stock…" style={{ ...inputStyle, minHeight:70, resize:"vertical" }} />
      </div>
      <div style={{ background:"#0f0f1a", borderRadius:8, padding:14, marginBottom:20 }}>
        <div style={{ fontSize:10, color:"#ffffff30", letterSpacing:"0.08em", marginBottom:8 }}>SMS PREVIEW</div>
        <div style={{ fontSize:12, color:"#ffffff70", lineHeight:1.7, whiteSpace:"pre-wrap" }}>{previewMsg}</div>
      </div>
      <div style={{ display:"flex", gap:10 }}>
        <button onClick={handleSend} disabled={sending} style={{ flex:1, background:sending?"#6b7280":"#10b981", color:"#fff", border:"none", padding:"12px 20px", borderRadius:8, cursor:sending?"not-allowed":"pointer", fontWeight:700, fontSize:15 }}>
          {sending ? "Sending…" : "📱 Send SMS Quote"}
        </button>
        <button onClick={onClose} style={{ background:"transparent", color:"#ffffff60", border:"1px solid #ffffff20", padding:"12px 20px", borderRadius:8, cursor:"pointer" }}>Cancel</button>
      </div>
    </div>
  );
}

const SERVICES = [
  { id:"batt",      label:"Battery Replacement",              price:41,    cat:"quick" },
  { id:"gasket",    label:"Gasket Replacement",               price:6,     cat:"quick" },
  { id:"prestest",  label:"Pressure Test",                    price:12,    cat:"quick" },
  { id:"springbar", label:"Spring Bar/Pin",                   price:6,     cat:"quick" },
  { id:"capac",     label:"Capacitor Replacement",            price:150,   cat:"quick" },
  { id:"ultrasonic",label:"Ultrasonic Clean",                 price:62,    cat:"quick" },
  { id:"hand",      label:"Hand Refitting",                   price:49.95, cat:"quick" },
  { id:"stem",      label:"Stem Replacement",                 price:49.95, cat:"quick" },
  { id:"crowng",    label:"Crown Replacement (Generic)",      price:39.95, cat:"quick" },
  { id:"crowngen",  label:"Crown Replacement (Genuine)",      price:0,     cat:"quick", quoted:true },
  { id:"glassminflt",label:"Mineral Flat Glass (custom cut)", price:59.95, cat:"glass" },
  { id:"glassmin",  label:"Mineral Glass Replacement",        price:59.95, cat:"glass" },
  { id:"glasssaph", label:"Sapphire Glass",                   price:99.95, cat:"glass" },
  { id:"glassplexi",label:"Plexi Glass (from)",               price:81,    cat:"glass" },
  { id:"polishbasic",label:"Basic Polish (light scratches)",  price:75,    cat:"polish" },
  { id:"polishmed", label:"Medium Polish (medium scratches)", price:112,   cat:"polish" },
  { id:"polishfull",label:"Full Refinish",                    price:150,   cat:"polish" },
  { id:"svcbasicwind",label:"Basic Mechanical Service",       price:438,   cat:"service" },
  { id:"svcauto",   label:"Automatic Service",                price:500,   cat:"service" },
  { id:"svcchrono", label:"Mechanical Chronograph Service",   price:688,   cat:"service" },
  { id:"svcquartz", label:"Basic Quartz Service",             price:375,   cat:"service" },
  { id:"svcqchrono",label:"Quartz Chronograph Service",       price:562,   cat:"service" },
];

const CAT_LABELS = { quick:"Quick Jobs & Extras", glass:"Glass Replacement", polish:"Case & Bracelet Polishing", service:"Full Service" };

const MOVEMENTS = {
  "251.242":389,"251.264":455,"251.274":368,"251.474":371,"255.491":239,
  "280.002":269,"802.002":118,"802.102":112,"803.112":118,"803.114":122,
  "803.124":122,"804.114":119,"804.124":122,"805.112":119,"805.114":122,
  "805.124":124,"901.001":132,"902.002":130,"902.101":130,"902.505":124,
  "955.112":166,"955.122":195,"955.412":166,"955.422":179,"956.112":169,
  "956.122":174,"956.412":166,"956.612":239,"976.001":252,"980.106":170,
  "980.108":170,"980.153":186,"980.163":186,"E01.001":558,"E03.001":252,
  "E61.041":236,"E61.111":236,"E63.041":236,"E63.111":236,"E64.111":236,
  "F03.111":120,"F04.111":120,"F05.111":120,"F05.115":140,"F06.111":120,
  "F06.115":138,"F06.161":186,"F07.111":154,"F07.115":154,"G10.212":245,
  "G10.712":198,"G15.211":196,"G15.212":245,"G15.261":217,
  "2824-2":135,"2836-2":135,"2892-A2":160,"6497-1":130,"6498-1":130,"7750":210,
  "1E20":174,"1F20":132,"1F21":186,"1N00":122,"1N01":122,"2E20":184,
  "7N00":124,"7N01":120,"7N32":124,"7N33":131,"7N39":128,"7N42":124,
  "7N43":134,"7N82":126,"7N83":134,"7N89":136,"7T62":364,"7T82":439,
  "AL20":98,"AL21":92,"AL32":95,"AL33":95,"AL35E":95,"AL55":95,
  "AL82":95,"AL83":95,"NH15":125,"NH35":125,"NH36":125,"PC10":95,
  "PC11":95,"PC20":95,"PC21":95,"PC22A":95,"PC23":95,"PC32":95,"PC33":95,
  "V021":134,"V501":108,"V657-20":268,"V810":120,"V811":124,"VB20B":98,
  "VC00":106,"VC01":118,"VC10E":101,"VC11":101,"VD34":148,"VD35":155,
  "VD51":105,"VD53":105,"VD54C":105,"VD55":105,"VD57B":105,"VD75A":105,
  "VD76":105,"VD77":105,"VD78":105,"VD79":142,"VD85":105,"VD87":105,
  "VE00":139,"VH64":151,"VH67":105,"VJ12":98,"VJ20C":98,"VJ21C":98,
  "VJ22":98,"VJ23":98,"VJ32":98,"VJ33B":98,"VJ34":99,"VJ42":98,
  "VJ52":99,"VJ53B":101,"VJ76A":114,"VK63A":130,"VK64A":130,"VK67":135,
  "VR32A":158,"VR33A":158,"VR3GA":206,"VR42B":221,"VS32A":165,"VS43":175,
  "VX00":106,"VX01":112,"VX10":101,"VX11":101,"VX12":100,"VX18":151,
  "VX32E":98,"VX33E":99,"VX36":140,"VX3L":100,"VX3N":100,"VX3P":141,
  "VX3R":145,"VX3S":154,"VX7JE":100,"VX7PE":141,"VX82":99,"VX83":101,
  "VX89":100,"VX9JE":145,"VX9NE":142,"VX9PE":145,"Y120":98,"Y121":94,
  "Y799":110,"YL50":161,"YL61":130,"YM62":162,"YM92":165,
  "0T45":124,"1102":121,"1L02":104,"1L12":100,"1L15":100,"1L22":99,"1L26":110,
  "1L32":104,"1L40":115,"1L45":110,"1M02":104,"1M12":104,"1M15":109,"1M50":100,
  "1N12":100,"1S02":102,"1S12":101,"1S13":101,"2005":100,"2015":100,"2025":96,
  "2033":95,"2035":95,"2036":96,"2039":99,"2105":100,"2115":104,"2305":101,
  "2315":96,"2405":112,"2415":95,"2510":95,"2F00":120,"2F10":120,"4S20":184,
  "5R21":105,"5R22":120,"5R32":130,"5Y20":104,"5Y30":104,"6L02":104,"6L40":120,
  "6M17":120,"6M50":120,"6N10":111,"6P20":131,"6P23":105,"6P25":105,"6P26":105,
  "6P27":144,"6P29":150,"6P73":165,"6P80":172,"6S20":176,"9T13":124,
  "9T15":120,"9T22":100,"9T33":115,"9U15":115,"B023":220,"B035":252,"E001":156,
  "E011":156,"E013":165,"E031":156,"E101":156,"E111":161,"E860":342,"E870":421,
  "FS00-4":169,"FS01":115,"FS20":115,"FS21":115,"FS60":115,
  "G620":204,"G870":275,"GL00":104,"GL10":100,"GL20":101,"GL22":101,"GL30":101,
  "GL32":101,"GL34":101,"GM00":104,"GM02":104,"GM10":100,"GM15":100,"GN10":100,
  "GN12":104,"GN15":100,"GP10":135,"GP11":128,"JR10":189,"JS15":155,"JS16":159,
  "JS25":145,"JS26":145,"OS10":162,"OS11":162,"OS20":115,"OS21":115,"OS30":115,
  "OS60":175,"OS62":185,"OS80":210,"OS90":210,"OU30":115,"OW50":291,"T241":146,
  "1005":236,"1016":244,"1019":244,"1032":134,"1042":165,"1062":114,"1063":115,
  "1064":124,"1069":124,"4003B":211,"4120BM":264,"4220B":329,"5010B":302,
  "5021D":206,"5030D":198,"5040":214,"5040B-SA":279,"505":106,"5050B":224,
  "507":112,"509":129,"512":110,"513":110,"5130D":232,"515":108,"517":151,
  "519":120,"585":108,"6003B":138,"6003D":145,"6004B":145,"702":138,"704":120,
  "705":120,"715":118,"751":108,"751E":140,"753":119,"762":104,"762-SA":122,
  "763":106,"763S":126,"774":116,"775":141,"782":131,"785":120,"8040":389,"Z60":176,
  "8172.220":120,"8174.220":120,"8272":120,"9232":120,"9238":120,
  "5820":115,"6120":115,"6130":115,"7021":115,"7022":115,"7122":115,"7221":115,
};

function NewRepairForm({ inputStyle, saving, newForm, setNewForm, handleNewRepair, ALL_STATUSES }) {
  const [selectedServices, setSelectedServices] = useState([]);
  const [movementSearch, setMovementSearch] = useState("");
  const [movementResult, setMovementResult] = useState(null);
  const [movementError, setMovementError] = useState(false);
  const [customItems, setCustomItems] = useState([]);
  const [customLabel, setCustomLabel] = useState("");
  const [customPrice, setCustomPrice] = useState("");
  const [isScanning, setIsScanning] = useState(false);
  const fileInputRef = useRef(null);

  function handleCameraTrigger() { fileInputRef.current?.click(); }

  async function handleImageUpload(e) {
    const file = e.target.files[0];
    if (!file) return;
    setIsScanning(true);
    try {
      const formData = new FormData();
      formData.append("photo", file);
      const res = await fetch(`${SERVER_URL}/analyze-watch`, {
        method: "POST",
        body: formData
      });
      if (!res.ok) throw new Error("Server error " + res.status);
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      if (data.brand && data.brand !== "null") {
        setNewForm(p => ({ ...p, watch_brand: data.brand }));
      }
      if (data.movement && data.movement !== "null") {
        const det = data.movement.toUpperCase().trim();
        const price = MOVEMENTS[det];
        if (price) {
          const result = { id:"movement", label:`Movement: ${det} (Scanned)`, price };
          setMovementResult(result);
          setMovementError(false);
          updateQuote(selectedServices, result, customItems);
          alert(`✅ Found: ${data.brand || ""} — Movement ${det} ($${price})`);
        } else {
          setMovementSearch(det);
          setMovementError(true);
          alert(`Found movement "${det}" but not in price list — add as custom item.`);
        }
      } else if (data.brand && data.brand !== "null") {
        alert(`✅ Brand detected: ${data.brand}\nNo movement number visible — fill in manually.`);
      } else {
        alert("Couldn't read the caseback clearly. Try a closer, well-lit photo.");
      }
    } catch (error) {
      alert("Scan failed: " + error.message);
    } finally {
      setIsScanning(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  function toggleService(svc) {
    setSelectedServices(prev => {
      const exists = prev.find(s => s.id === svc.id);
      const item = svc.quoted ? { ...svc, label: svc.label + " (to be quoted)", price: 0 } : svc;
      const next = exists ? prev.filter(s => s.id !== svc.id) : [...prev, item];
      updateQuote(next, movementResult, customItems);
      return next;
    });
  }

  function searchMovement() {
    const q = movementSearch.trim().toUpperCase();
    const price = MOVEMENTS[q] || MOVEMENTS[movementSearch.trim()];
    if (price) {
      const result = { id:"movement", label:`Movement: ${movementSearch.trim().toUpperCase()}`, price };
      setMovementResult(result);
      setMovementError(false);
      updateQuote(selectedServices, result, customItems);
    } else {
      setMovementResult(null);
      setMovementError(true);
    }
  }

  function removeMovement() {
    setMovementResult(null);
    setMovementSearch("");
    setMovementError(false);
    updateQuote(selectedServices, null, customItems);
  }

  function addCustomItem() {
    if (!customLabel.trim() || !customPrice) return;
    const item = { id:"custom-"+Date.now(), label:customLabel.trim(), price:parseFloat(customPrice) };
    const next = [...customItems, item];
    setCustomItems(next);
    setCustomLabel(""); setCustomPrice("");
    updateQuote(selectedServices, movementResult, next);
  }

  function removeCustomItem(id) {
    const next = customItems.filter(i => i.id !== id);
    setCustomItems(next);
    updateQuote(selectedServices, movementResult, next);
  }

  function updateQuote(services, movement, customs) {
    const all = [...services, ...(movement ? [movement] : []), ...customs];
    const total = all.reduce((s, i) => s + i.price, 0);
    const breakdown = all.map(i => `${i.label}: $${i.price}`).join("\n");
    setNewForm(p => ({ ...p, quote: total > 0 ? total : "", issue: breakdown }));
  }

  const allItems = [...selectedServices, ...(movementResult ? [movementResult] : []), ...customItems];
  const total = allItems.reduce((s, i) => s + i.price, 0);
  const btnBase = { border:"none", borderRadius:10, padding:"8px 14px", cursor:"pointer", fontSize:14, fontWeight:600, transition:"all 0.15s" };

  return (
    <div style={{ padding:"20px 16px", maxWidth:800 }}>
      <h1 style={{ margin:"0 0 20px", fontSize:24 }}>New Repair Ticket</h1>

      <input type="file" accept="image/*" capture="environment" ref={fileInputRef} style={{ display:"none" }} onChange={handleImageUpload} />

      <div style={{ background:"#1a1a2e", borderRadius:15, padding:20, marginBottom:16 }}>
        <div style={{ fontSize:12, color:"#ffffff40", letterSpacing:"0.08em", marginBottom:14 }}>CUSTOMER & WATCH DETAILS</div>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
          {[["team_member","Team Member","text"],["customer_name","Customer Name","text"],["phone","Phone Number","tel"]].map(([key,label,type]) => (
            <div key={key}>
              <label style={{ fontSize:11, color:"#ffffff40", letterSpacing:"0.07em", display:"block", marginBottom:5 }}>{label.toUpperCase()}</label>
              <input type={type} value={newForm[key]} onChange={e => setNewForm(p => ({ ...p, [key]:e.target.value }))} style={inputStyle} />
            </div>
          ))}
          <div>
            <label style={{ fontSize:11, color:"#ffffff40", letterSpacing:"0.07em", display:"block", marginBottom:5 }}>BRAND / WATCH</label>
            <div style={{ display:"flex", gap:8 }}>
              <input type="text" value={newForm.watch_brand} onChange={e => setNewForm(p => ({ ...p, watch_brand:e.target.value }))} style={{ ...inputStyle, flex:1 }} />
              <button onClick={handleCameraTrigger} disabled={isScanning} style={{ background:isScanning?"#6b7280":"#10b981", color:"#fff", border:"none", borderRadius:10, padding:"0 12px", cursor:isScanning?"not-allowed":"pointer", fontWeight:700, fontSize:13, whiteSpace:"nowrap" }}>
                {isScanning ? "⏳" : "📸"}
              </button>
            </div>
          </div>
          <div>
            <label style={{ fontSize:11, color:"#ffffff40", letterSpacing:"0.07em", display:"block", marginBottom:5 }}>EST. READY DATE</label>
            <input type="date" value={newForm.estimated_ready} onChange={e => setNewForm(p => ({ ...p, estimated_ready:e.target.value }))} style={inputStyle} />
          </div>
          <div>
            <label style={{ fontSize:11, color:"#ffffff40", letterSpacing:"0.07em", display:"block", marginBottom:5 }}>STATUS</label>
            <select value={newForm.status} onChange={e => setNewForm(p => ({ ...p, status:e.target.value }))} style={{ ...inputStyle, cursor:"pointer" }}>
              {ALL_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
        </div>
      </div>

      <div style={{ background:"#1a1a2e", borderRadius:15, padding:20, marginBottom:16 }}>
        <div style={{ fontSize:12, color:"#ffffff40", letterSpacing:"0.08em", marginBottom:16 }}>JOB BUILDER</div>
        {Object.entries(CAT_LABELS).map(([cat, catLabel]) => (
          <div key={cat} style={{ marginBottom:16 }}>
            <div style={{ fontSize:12, color:"#c9a84c", letterSpacing:"0.08em", marginBottom:8 }}>{catLabel}</div>
            <div style={{ display:"flex", flexWrap:"wrap", gap:6 }}>
              {SERVICES.filter(s => s.cat === cat).map(svc => {
                const active = selectedServices.find(s => s.id === svc.id);
                return (
                  <button key={svc.id} onClick={() => toggleService(svc)} style={{ ...btnBase, background:active?"#c9a84c":"#ffffff10", color:active?"#1a1a2e":"#fff", border:active?"none":"1px solid #ffffff20" }}>
                    {svc.label} <span style={{ opacity:0.7, marginLeft:4 }}>{svc.quoted ? "(Quote)" : "$"+svc.price}</span>
                  </button>
                );
              })}
            </div>
          </div>
        ))}

        <div style={{ borderTop:"1px solid #ffffff10", paddingTop:16, marginBottom:16 }}>
          <div style={{ fontSize:12, color:"#c9a84c", letterSpacing:"0.08em", marginBottom:8 }}>MOVEMENT REPLACEMENT</div>
          <div style={{ display:"flex", gap:8, flexWrap:"wrap", alignItems:"center" }}>
            <input placeholder="e.g. 7N42, 2824-2, NH35…" value={movementSearch} onChange={e => { setMovementSearch(e.target.value); setMovementError(false); }} onKeyDown={e => e.key==="Enter" && searchMovement()} style={{ ...inputStyle, maxWidth:260 }} />
            <button onClick={searchMovement} style={{ ...btnBase, background:"#ffffff20", color:"#fff", padding:"10px 16px" }}>Search</button>
            {movementResult && (
              <div style={{ display:"flex", alignItems:"center", gap:8, background:"#c9a84c20", border:"1px solid #c9a84c50", borderRadius:10, padding:"8px 12px" }}>
                <span style={{ color:"#c9a84c", fontWeight:700, fontSize:13 }}>{movementResult.label} — ${movementResult.price}</span>
                <button onClick={removeMovement} style={{ background:"transparent", border:"none", color:"#c9a84c", cursor:"pointer", fontSize:18 }}>×</button>
              </div>
            )}
          </div>
          {movementError && <div style={{ color:"#ef4444", fontSize:13, marginTop:6 }}>Not found — add as custom item below</div>}
        </div>

        <div style={{ borderTop:"1px solid #ffffff10", paddingTop:16 }}>
          <div style={{ fontSize:12, color:"#c9a84c", letterSpacing:"0.08em", marginBottom:8 }}>ADD CUSTOM ITEM / PARTS</div>
          <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
            <input placeholder="Description" value={customLabel} onChange={e => setCustomLabel(e.target.value)} style={{ ...inputStyle, flex:2, minWidth:160 }} />
            <input placeholder="Price $" type="number" value={customPrice} onChange={e => setCustomPrice(e.target.value)} onKeyDown={e => e.key==="Enter" && addCustomItem()} style={{ ...inputStyle, width:90 }} />
            <button onClick={addCustomItem} style={{ ...btnBase, background:"#ffffff20", color:"#fff", padding:"10px 16px" }}>Add</button>
          </div>
          {customItems.length > 0 && (
            <div style={{ marginTop:10, display:"flex", flexWrap:"wrap", gap:6 }}>
              {customItems.map(item => (
                <div key={item.id} style={{ display:"flex", alignItems:"center", gap:8, background:"#ffffff10", border:"1px solid #ffffff20", borderRadius:8, padding:"5px 10px" }}>
                  <span style={{ fontSize:13, color:"#fff" }}>{item.label} — ${item.price}</span>
                  <button onClick={() => removeCustomItem(item.id)} style={{ background:"transparent", border:"none", color:"#ffffff60", cursor:"pointer", fontSize:15 }}>×</button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {allItems.length > 0 && (
        <div style={{ background:"#1a1a2e", borderRadius:15, padding:20, marginBottom:16 }}>
          <div style={{ fontSize:12, color:"#ffffff40", letterSpacing:"0.08em", marginBottom:12 }}>QUOTE BREAKDOWN</div>
          {allItems.map((item, i) => (
            <div key={i} style={{ display:"flex", justifyContent:"space-between", padding:"7px 0", borderBottom:"1px solid #ffffff08", fontSize:14 }}>
              <span style={{ color:"#ffffff90" }}>{item.label}</span>
              <span style={{ color:"#fff", fontWeight:600 }}>${item.price}</span>
            </div>
          ))}
          <div style={{ display:"flex", justifyContent:"space-between", padding:"12px 0 0", fontSize:20, fontWeight:700 }}>
            <span style={{ color:"#ffffff60" }}>TOTAL</span>
            <span style={{ color:"#c9a84c" }}>${total}</span>
          </div>
        </div>
      )}

      <div style={{ background:"#1a1a2e", borderRadius:15, padding:20, marginBottom:16 }}>
        <div style={{ fontSize:12, color:"#ffffff40", letterSpacing:"0.08em", marginBottom:10 }}>ADDITIONAL NOTES</div>
        <textarea value={newForm.notes} onChange={e => setNewForm(p => ({ ...p, notes:e.target.value }))} placeholder="Any extra notes for the workshop…" style={{ ...inputStyle, minHeight:70, resize:"vertical" }} />
      </div>

      <div style={{ display:"flex", gap:12, alignItems:"center" }}>
        <button onClick={handleNewRepair} disabled={saving} style={{ background:saving?"#6b7280":"#c9a84c", color:"#1a1a2e", border:"none", padding:"13px 28px", borderRadius:12, cursor:saving?"not-allowed":"pointer", fontWeight:700, fontSize:15 }}>
          {saving ? "Saving…" : "Create Ticket & Print →"}
        </button>
      </div>
    </div>
  );
}

function CustomerPage({ repair, onBack }) {
  const cfg = STATUS_CONFIG[repair.status] || { color: "#6B7280", bg: "#F9FAFB" };
  const history = repair.history || [];
  return (
    <div style={{ minHeight:"100vh", background:"#f8f7f4", fontFamily:"'Georgia', serif" }}>
      <div style={{ background:"#1a1a2e", padding:"20px 24px", display:"flex", alignItems:"center", gap:16 }}>
        <div style={{ color:"#c9a84c", fontSize:22, fontWeight:700, letterSpacing:"0.1em" }}>⌚ CHRONO</div>
        <div style={{ color:"#ffffff60", fontSize:13 }}>REPAIR STUDIO</div>
        {onBack && <button onClick={onBack} style={{ marginLeft:"auto", background:"transparent", border:"1px solid #ffffff40", color:"#fff", padding:"6px 16px", borderRadius:6, cursor:"pointer", fontSize:13 }}>← Staff View</button>}
      </div>
      <div style={{ maxWidth:540, margin:"0 auto", padding:"32px 20px" }}>
        <div style={{ background:"#fff", borderRadius:16, padding:28, marginBottom:20, boxShadow:"0 2px 12px rgba(0,0,0,0.07)", textAlign:"center" }}>
          <div style={{ fontSize:12, color:"#9ca3af", letterSpacing:"0.08em", marginBottom:6 }}>REPAIR TICKET</div>
          <div style={{ fontSize:26, fontWeight:700, color:"#1a1a2e", marginBottom:4 }}>{repair.id}</div>
          <div style={{ fontSize:15, color:"#374151", marginBottom:20 }}>{repair.watch_brand}</div>
          <div style={{ background:cfg.bg, border:`2px solid ${cfg.color}40`, borderRadius:12, padding:"14px 20px", marginBottom:16 }}>
            <div style={{ fontSize:11, color:cfg.color, letterSpacing:"0.1em", marginBottom:4 }}>CURRENT STATUS</div>
            <div style={{ fontSize:20, fontWeight:700, color:cfg.color }}>{repair.status}</div>
          </div>
          {repair.status === "Ready for Collection" && (
            <div style={{ background:"#ecfdf5", border:"1px solid #10b98140", borderRadius:10, padding:14, marginBottom:12, fontSize:14, color:"#065f46" }}>
              🎉 Your watch is ready! Please bring this ticket when collecting.
            </div>
          )}
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, textAlign:"left" }}>
            <div style={{ background:"#f9fafb", borderRadius:8, padding:12 }}>
              <div style={{ fontSize:11, color:"#9ca3af" }}>RECEIVED</div>
              <div style={{ fontSize:14, fontWeight:600, marginTop:2 }}>{repair.received_date}</div>
            </div>
            <div style={{ background:"#f9fafb", borderRadius:8, padding:12 }}>
              <div style={{ fontSize:11, color:"#9ca3af" }}>EST. READY</div>
              <div style={{ fontSize:14, fontWeight:600, marginTop:2 }}>{repair.estimated_ready || "TBC"}</div>
            </div>
          </div>
        </div>
        {repair.issue && (
          <div style={{ background:"#fff", borderRadius:16, padding:24, marginBottom:20, boxShadow:"0 2px 12px rgba(0,0,0,0.07)" }}>
            <div style={{ fontSize:12, color:"#6b7280", letterSpacing:"0.06em", marginBottom:12 }}>WORK BEING DONE</div>
            <div style={{ fontSize:14, color:"#374151", lineHeight:1.7 }}>{repair.issue}</div>
          </div>
        )}
        {history.length > 0 && (
          <div style={{ background:"#fff", borderRadius:16, padding:24, marginBottom:20, boxShadow:"0 2px 12px rgba(0,0,0,0.07)" }}>
            <div style={{ fontSize:12, color:"#6b7280", letterSpacing:"0.06em", marginBottom:20 }}>REPAIR HISTORY</div>
            {history.map((h, i) => (
              <div key={i} style={{ display:"flex", gap:12, marginBottom:i < history.length-1 ? 14 : 0 }}>
                <div style={{ display:"flex", flexDirection:"column", alignItems:"center" }}>
                  <div style={{ width:9, height:9, borderRadius:"50%", background:i===history.length-1?"#c9a84c":"#d1d5db", flexShrink:0, marginTop:3 }} />
                  {i < history.length-1 && <div style={{ width:1, flex:1, background:"#e5e7eb", minHeight:18, marginTop:3 }} />}
                </div>
                <div>
                  <div style={{ fontSize:11, color:"#9ca3af" }}>{h.date}</div>
                  <div style={{ fontSize:13, color:"#374151" }}>{h.event}</div>
                </div>
              </div>
            ))}
          </div>
        )}
        <div style={{ textAlign:"center", color:"#9ca3af", fontSize:12 }}>Questions? Call us on 03 9123 4567</div>
      </div>
    </div>
  );
}

export default function App() {
  const [repairs, setRepairs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [view, setView] = useState("dashboard");
  const [selected, setSelected] = useState(null);
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("All");
  const [sortField, setSortField] = useState("received_date");
  const [sortDir, setSortDir] = useState("desc");
  const [scanInput, setScanInput] = useState("");
  const [scanResult, setScanResult] = useState(null);
  const [scanError, setScanError] = useState(false);
  const [saving, setSaving] = useState(false);
  const [notification, setNotification] = useState(null);
  const [quoteModal, setQuoteModal] = useState(null);
  const [noteInput, setNoteInput] = useState("");
  const [newForm, setNewForm] = useState({ team_member:"", customer_name:"", phone:"", watch_brand:"", issue:"", cost_to_business:"", quote:"", estimated_ready:"", status:"Go Ahead", notes:"" });

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const action = params.get("action");
    const repairId = params.get("repair");
    const response = params.get("response");
    if (action === "respond" && repairId && response) {
      handleCustomerResponse(repairId, response);
    } else if (repairId) {
      loadSingleRepair(repairId);
    } else {
      loadRepairs();
    }
  }, []);

  async function handleCustomerResponse(repairId, response) {
    setView("responding");
    try {
      const res = await fetch(`${SERVER_URL}/customer-respond`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ repairId, response }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setView("response_done");
      setSelected({ id: repairId, status: data.status, response });
    } catch(e) {
      setView("response_error");
    }
  }

  async function handleSendQuote(repairId, quote, message) {
    try {
      const res = await fetch(`${SERVER_URL}/send-quote`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": `Bearer ${SUPABASE_KEY}` },
        body: JSON.stringify({ repairId, quote: parseFloat(quote), message }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setNotification({ type:"success", msg:"Quote SMS sent to customer!" });
      setQuoteModal(null);
      await loadRepairs();
      setTimeout(() => setNotification(null), 4000);
    } catch(e) {
      setNotification({ type:"error", msg:"Failed to send: " + e.message });
      setTimeout(() => setNotification(null), 5000);
    }
  }

  async function loadSingleRepair(id) {
    try {
      const data = await sbFetch(`repairs?id=eq.${encodeURIComponent(id)}`);
      if (data.length > 0) { setSelected(data[0]); setView("customer"); }
      setLoading(false);
    } catch(e) { setLoading(false); }
  }

  async function loadRepairs() {
    try {
      setLoading(true); setError(null);
      const data = await sbFetch("repairs?order=received_date.desc.nullslast,id.desc");
      setRepairs(data);
    } catch(e) {
      setError("Could not connect: " + e.message);
    } finally {
      setLoading(false);
    }
  }

  async function handleNewRepair() {
    try {
      setSaving(true);
      const id = "WR-" + Date.now();
      const today = new Date().toISOString().slice(0, 10);
      const repair = { ...newForm, id, received_date: today, cost_to_business: parseFloat(newForm.cost_to_business) || null, quote: parseFloat(newForm.quote) || null, history: [{ date: today, event: "Watch received and logged" }] };
      await sbFetch("repairs", { method:"POST", body:JSON.stringify(repair), prefer:"return=representation" });
      await loadRepairs();
      const newRepairs = await sbFetch(`repairs?id=eq.${id}`);
      if (newRepairs.length > 0) printTicket(newRepairs[0]);
      setView("dashboard");
      setNewForm({ team_member:"", customer_name:"", phone:"", watch_brand:"", issue:"", cost_to_business:"", quote:"", estimated_ready:"", status:"Go Ahead", notes:"" });
    } catch(e) {
      alert("Error saving: " + e.message);
    } finally {
      setSaving(false);
    }
  }

  async function handleStatusChange(id, status) {
    try {
      const today = new Date().toISOString().slice(0, 10);
      const repair = repairs.find(r => r.id === id) || selected;
      const history = [...(repair.history || []), { date: today, event: `Status updated to: ${status}` }];
      await sbFetch(`repairs?id=eq.${encodeURIComponent(id)}`, { method:"PATCH", body:JSON.stringify({ status, history }), prefer:"return=representation" });
      setSelected(prev => prev ? { ...prev, status, history } : prev);
      setRepairs(prev => prev.map(r => r.id === id ? { ...r, status, history } : r));
    } catch(e) { alert("Error: " + e.message); }
  }

  async function handleAddNote(id, note) {
    if (!note.trim()) return;
    try {
      const today = new Date().toISOString().slice(0, 10);
      const repair = repairs.find(r => r.id === id) || selected;
      const notes = (repair.notes ? repair.notes + "\n" : "") + note;
      const history = [...(repair.history || []), { date: today, event: note }];
      await sbFetch(`repairs?id=eq.${encodeURIComponent(id)}`, { method:"PATCH", body:JSON.stringify({ notes, history }), prefer:"return=representation" });
      setSelected(prev => prev ? { ...prev, notes, history } : prev);
      setRepairs(prev => prev.map(r => r.id === id ? { ...r, notes, history } : r));
      setNoteInput("");
    } catch(e) { alert("Error: " + e.message); }
  }

  function handleScan() {
    const q = scanInput.trim().toLowerCase();
    const found = repairs.find(r => r.id.toLowerCase() === q || (r.phone && r.phone.replace(/\s/g,"").includes(q.replace(/\s/g,""))));
    if (found) { setScanResult(found); setScanError(false); }
    else { setScanResult(null); setScanError(true); }
  }

  function deadlineBadge(receivedDate) {
    if (!receivedDate) return null;
    const days = Math.floor((new Date() - new Date(receivedDate)) / 86400000);
    if (days >= 9) return { label:`${days}d ⚠️ OVERDUE`, color:"#ef4444", bg:"#1a0000" };
    if (days >= 6) return { label:`${days}d ⚡ Due soon`, color:"#f59e0b", bg:"#1a1200" };
    return null;
  }

  const filtered = repairs
    .filter(r => {
      const q = search.toLowerCase();
      const matchSearch = !q || (r.customer_name||"").toLowerCase().includes(q) || (r.id||"").toLowerCase().includes(q) || (r.watch_brand||"").toLowerCase().includes(q) || (r.phone||"").includes(q) || (r.team_member||"").toLowerCase().includes(q);
      return matchSearch && (filterStatus === "All" || r.status === filterStatus);
    })
    .sort((a, b) => {
      const av = a[sortField] || ""; const bv = b[sortField] || "";
      const cmp = av < bv ? -1 : av > bv ? 1 : 0;
      return sortDir === "desc" ? -cmp : cmp;
    });

  const counts = ALL_STATUSES.reduce((a, s) => ({ ...a, [s]: repairs.filter(r => r.status === s).length }), {});

  if (view === "customer" && selected) return <CustomerPage repair={selected} onBack={() => setView("detail")} />;

  const inputStyle = { width:"100%", background:"#0f0f1a", border:"1px solid #ffffff20", color:"#fff", borderRadius:10, padding:"10px 14px", fontSize:15, boxSizing:"border-box", outline:"none" };

  return (
    <div style={{ fontFamily:"'Georgia', serif", minHeight:"100vh", background:"#0f0f1a", color:"#fff", display:"flex" }}>

      {/* Responsive styles */}
      <style>{`
        .sidebar { width:240px; background:#1a1a2e; flex-shrink:0; display:flex; flex-direction:column; position:sticky; top:0; height:100vh; overflow-y:auto; }
        .bottom-nav { display:none; }
        .desktop-table { display:block; }
        .mobile-cards { display:none; }
        @media (max-width: 768px) {
          .sidebar { display: none !important; }
          .bottom-nav { display: flex !important; position:fixed; bottom:0; left:0; right:0; background:#1a1a2e; border-top:1px solid #ffffff15; z-index:500; padding:8px 0 14px; justify-content:space-around; }
          .main-scroll { padding-bottom: 80px !important; }
          .desktop-table { display: none !important; }
          .mobile-cards { display: block !important; }
        }
      `}</style>

      {/* Responding / Response done views */}
      {view === "responding" && (
        <div style={{ flex:1, display:"flex", alignItems:"center", justifyContent:"center" }}>
          <div style={{ textAlign:"center", color:"#ffffff60" }}><div style={{ fontSize:32, marginBottom:16 }}>⏳</div><div>Processing…</div></div>
        </div>
      )}
      {(view === "response_done" || view === "response_error") && selected && (
        <div style={{ flex:1, display:"flex", alignItems:"center", justifyContent:"center", background:"#f8f7f4" }}>
          <div style={{ background:"#fff", borderRadius:20, padding:40, maxWidth:420, textAlign:"center", boxShadow:"0 4px 24px rgba(0,0,0,0.1)", fontFamily:"Georgia, serif" }}>
            <div style={{ fontSize:48, marginBottom:16 }}>{view === "response_error" ? "❌" : selected.response === "go" ? "✅" : "❌"}</div>
            <div style={{ fontSize:24, fontWeight:700, color:"#1a1a2e", marginBottom:12 }}>
              {view === "response_error" ? "Something went wrong" : selected.response === "go" ? "Go Ahead Confirmed!" : "No Problem!"}
            </div>
            <div style={{ fontSize:15, color:"#6b7280", lineHeight:1.7 }}>
              {view === "response_error" ? "We couldn't record your response. Please call us directly." : selected.response === "go" ? "We've received your approval and will get started on your repair!" : "We've noted your decision. Please contact us to discuss further."}
            </div>
            <div style={{ marginTop:24, fontSize:13, color:"#9ca3af" }}>⌚ Chrono Repair Studio</div>
          </div>
        </div>
      )}

      {/* Notification banner */}
      {notification && (
        <div style={{ position:"fixed", top:20, right:20, zIndex:1000, background:notification.type==="success"?"#065f46":"#7f1d1d", border:`1px solid ${notification.type==="success"?"#10b981":"#ef4444"}`, color:"#fff", borderRadius:10, padding:"14px 20px", fontSize:14, fontWeight:600, boxShadow:"0 4px 20px rgba(0,0,0,0.3)", maxWidth:340 }}>
          {notification.type === "success" ? "✅ " : "❌ "}{notification.msg}
        </div>
      )}

      {/* Quote Modal */}
      {quoteModal && (() => {
        const r = repairs.find(x => x.id === quoteModal);
        return (
          <div style={{ position:"fixed", inset:0, background:"#000000a0", zIndex:900, display:"flex", alignItems:"center", justifyContent:"center" }}>
            <div style={{ background:"#1a1a2e", borderRadius:16, padding:28, width:480, maxWidth:"92vw", boxShadow:"0 8px 40px rgba(0,0,0,0.5)" }}>
              <div style={{ fontSize:18, fontWeight:700, marginBottom:6 }}>Send Quote to Customer</div>
              <div style={{ fontSize:13, color:"#ffffff50", marginBottom:20 }}>{r?.customer_name} — {r?.watch_brand} — {r?.phone}</div>
              <QuoteModalForm repair={r} onSend={handleSendQuote} onClose={() => setQuoteModal(null)} inputStyle={inputStyle} />
            </div>
          </div>
        );
      })()}

      {/* Sidebar - desktop only */}
      <div className="sidebar">
        <div style={{ padding:"22px 18px", borderBottom:"1px solid #ffffff10" }}>
          <div style={{ color:"#c9a84c", fontSize:20, fontWeight:700, letterSpacing:"0.08em" }}>⌚ CHRONO</div>
          <div style={{ color:"#ffffff40", fontSize:12, letterSpacing:"0.1em", marginTop:2 }}>REPAIR STUDIO</div>
        </div>
        {[{ id:"dashboard", label:"Dashboard", icon:"▦" },{ id:"scan", label:"Scan / Lookup", icon:"⊙" },{ id:"new", label:"New Repair", icon:"+" }].map(item => (
          <button key={item.id} onClick={() => { setView(item.id); setSelected(null); }} style={{ background:view===item.id?"#ffffff12":"transparent", border:"none", borderLeft:view===item.id?"3px solid #c9a84c":"3px solid transparent", color:view===item.id?"#fff":"#ffffff60", padding:"11px 18px", textAlign:"left", cursor:"pointer", fontSize:15, display:"flex", alignItems:"center", gap:10 }}>
            <span>{item.icon}</span>{item.label}
          </button>
        ))}
        <div style={{ marginTop:"auto", padding:"14px 18px", borderTop:"1px solid #ffffff10" }}>
          <div style={{ fontSize:11, color:"#ffffff30", letterSpacing:"0.06em", marginBottom:8 }}>STATUS SUMMARY</div>
          {ALL_STATUSES.filter(s => counts[s] > 0).map(s => (
            <div key={s} style={{ display:"flex", justifyContent:"space-between", fontSize:13, color:"#ffffff50", marginBottom:3 }}>
              <span>{s}</span><span style={{ color:STATUS_CONFIG[s].color, fontWeight:700 }}>{counts[s]}</span>
            </div>
          ))}
          <button onClick={loadRepairs} style={{ marginTop:12, width:"100%", background:"transparent", border:"1px solid #ffffff20", color:"#ffffff60", borderRadius:8, padding:"5px", cursor:"pointer", fontSize:11 }}>↻ Refresh</button>
        </div>
      </div>

      {/* Main content */}
      <div className="main-scroll" style={{ flex:1, overflow:"auto" }}>

        {/* DASHBOARD */}
        {view === "dashboard" && !selected && (
          <div style={{ padding:"20px 16px" }}>
            <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:20 }}>
              <div>
                <h1 style={{ margin:0, fontSize:22 }}>Repair Jobs</h1>
                <div style={{ color:"#ffffff50", fontSize:14, marginTop:2 }}>{repairs.length} total</div>
              </div>
              <button onClick={() => setView("new")} style={{ background:"#c9a84c", color:"#1a1a2e", border:"none", padding:"9px 18px", borderRadius:10, cursor:"pointer", fontWeight:700, fontSize:13 }}>+ New</button>
            </div>
            {error && <div style={{ background:"#1a1a2e", border:"1px solid #ef4444", borderRadius:10, padding:16, color:"#ef4444", marginBottom:16 }}>{error}</div>}
            <div style={{ display:"flex", gap:10, marginBottom:20, flexWrap:"wrap" }}>
              <input placeholder="Search name, ID, brand, phone…" value={search} onChange={e => setSearch(e.target.value)} style={{ flex:1, minWidth:200, background:"#ffffff0d", border:"1px solid #ffffff20", color:"#fff", borderRadius:10, padding:"9px 12px", fontSize:14, outline:"none" }} />
              <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)} style={{ background:"#ffffff0d", border:"1px solid #ffffff20", color:"#fff", borderRadius:10, padding:"9px 12px", fontSize:14, cursor:"pointer" }}>
                <option value="All">All Statuses</option>
                {ALL_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>

            {loading ? <div style={{ textAlign:"center", padding:60, color:"#ffffff30" }}>Loading…</div> : (<>
              {/* Desktop table */}
              <div className="desktop-table" style={{ background:"#1a1a2e", borderRadius:12, overflow:"hidden" }}>
                <div style={{ display:"grid", gridTemplateColumns:"140px 1fr 1fr 110px 150px 70px 90px", padding:"10px 16px", borderBottom:"1px solid #ffffff10", fontSize:11, color:"#ffffff40", letterSpacing:"0.07em" }}>
                  <span>TICKET</span><span>CUSTOMER</span><span>WATCH</span><span>TEAM</span><span>STATUS</span><span>QUOTE</span><span>DATE IN</span>
                </div>
                {filtered.length === 0 && <div style={{ padding:40, textAlign:"center", color:"#ffffff30" }}>No repairs found</div>}
                {filtered.map((r, i) => (
                  <div key={r.id} onClick={() => { setSelected(r); setView("detail"); }} style={{ display:"grid", gridTemplateColumns:"140px 1fr 1fr 110px 150px 70px 90px", padding:"12px 16px", cursor:"pointer", borderBottom:i<filtered.length-1?"1px solid #ffffff08":"none" }}
                    onMouseEnter={e => e.currentTarget.style.background="#ffffff08"} onMouseLeave={e => e.currentTarget.style.background="transparent"}>
                    <span style={{ color:"#c9a84c", fontSize:13, fontWeight:600 }}>{r.id}</span>
                    <div><div style={{ fontSize:13 }}>{r.customer_name}</div><div style={{ fontSize:11, color:"#ffffff40", marginTop:1 }}>{r.phone}</div></div>
                    <span style={{ fontSize:13, color:"#ffffff80", alignSelf:"center" }}>{r.watch_brand}</span>
                    <span style={{ fontSize:12, color:"#ffffff50", alignSelf:"center" }}>{r.team_member}</span>
                    <div style={{ alignSelf:"center", display:"flex", flexDirection:"column", gap:3 }}>
                      <StatusBadge status={r.status} />
                      {deadlineBadge(r.received_date) && (
                        <span style={{ fontSize:10, fontWeight:700, color:deadlineBadge(r.received_date).color, background:deadlineBadge(r.received_date).bg, borderRadius:4, padding:"1px 5px", border:`1px solid ${deadlineBadge(r.received_date).color}40` }}>
                          {deadlineBadge(r.received_date).label}
                        </span>
                      )}
                    </div>
                    <span style={{ fontSize:13, alignSelf:"center" }}>{r.quote!=null?`$${r.quote}`:"—"}</span>
                    <span style={{ fontSize:11, color:"#ffffff50", alignSelf:"center" }}>{r.received_date||"—"}</span>
                  </div>
                ))}
              </div>

              {/* Mobile cards */}
              <div className="mobile-cards">
                {filtered.length === 0 && <div style={{ padding:40, textAlign:"center", color:"#ffffff30" }}>No repairs found</div>}
                {filtered.map(r => (
                  <div key={r.id} onClick={() => { setSelected(r); setView("detail"); }}
                    style={{ background:"#1a1a2e", borderRadius:12, padding:16, marginBottom:10, cursor:"pointer", border:"1px solid #ffffff08" }}>
                    <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:8 }}>
                      <span style={{ color:"#c9a84c", fontSize:13, fontWeight:700 }}>{r.id}</span>
                      <StatusBadge status={r.status} />
                    </div>
                    <div style={{ fontSize:17, fontWeight:700, marginBottom:3 }}>{r.customer_name || "—"}</div>
                    <div style={{ fontSize:14, color:"#ffffff60", marginBottom:8 }}>{r.watch_brand || "—"}</div>
                    <div style={{ display:"flex", justifyContent:"space-between", fontSize:12, color:"#ffffff40" }}>
                      <span>📞 {r.phone || "—"}</span>
                      <span>{r.quote != null ? `$${r.quote}` : "No quote"}</span>
                      <span>{r.received_date || "—"}</span>
                    </div>
                    {deadlineBadge(r.received_date) && (
                      <div style={{ marginTop:8 }}>
                        <span style={{ fontSize:11, fontWeight:700, color:deadlineBadge(r.received_date).color, background:deadlineBadge(r.received_date).bg, borderRadius:4, padding:"2px 8px", border:`1px solid ${deadlineBadge(r.received_date).color}40` }}>
                          {deadlineBadge(r.received_date).label}
                        </span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </>)}
          </div>
        )}

        {/* DETAIL */}
        {view === "detail" && selected && (
          <div style={{ padding:"20px 16px", maxWidth:900 }}>
            <div style={{ display:"flex", alignItems:"center", gap:12, marginBottom:24, flexWrap:"wrap" }}>
              <button onClick={() => { setSelected(null); setView("dashboard"); }} style={{ background:"transparent", border:"1px solid #ffffff30", color:"#fff", padding:"6px 14px", borderRadius:8, cursor:"pointer", fontSize:13 }}>← Back</button>
              <h1 style={{ margin:0, fontSize:18 }}>{selected.id}</h1>
              <StatusBadge status={selected.status} />
              <div style={{ marginLeft:"auto", display:"flex", gap:8, flexWrap:"wrap" }}>
                {selected.phone && (
                  <button onClick={() => setQuoteModal(selected.id)} style={{ background:"#10b981", color:"#fff", border:"none", padding:"7px 14px", borderRadius:8, cursor:"pointer", fontWeight:700, fontSize:13 }}>💬 Quote</button>
                )}
                <button onClick={() => printTicket(selected)} style={{ background:"#ffffff15", color:"#fff", border:"1px solid #ffffff30", padding:"7px 14px", borderRadius:8, cursor:"pointer", fontSize:13 }}>🖨 Print</button>
                <button onClick={() => setView("customer")} style={{ background:"#c9a84c", color:"#1a1a2e", border:"none", padding:"7px 14px", borderRadius:8, cursor:"pointer", fontWeight:700, fontSize:13 }}>👁 Customer</button>
              </div>
            </div>

            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16, marginBottom:16 }}>
              <div style={{ background:"#1a1a2e", borderRadius:12, padding:18 }}>
                <div style={{ fontSize:11, color:"#ffffff40", letterSpacing:"0.08em", marginBottom:10 }}>CUSTOMER</div>
                <div style={{ fontSize:20, fontWeight:700, marginBottom:6 }}>{selected.customer_name}</div>
                <div style={{ fontSize:14, color:"#ffffff70", marginBottom:3 }}>📞 {selected.phone||"—"}</div>
                <div style={{ fontSize:14, color:"#ffffff50" }}>👤 {selected.team_member||"—"}</div>
              </div>
              <div style={{ background:"#1a1a2e", borderRadius:12, padding:18 }}>
                <div style={{ fontSize:11, color:"#ffffff40", letterSpacing:"0.08em", marginBottom:10 }}>WATCH</div>
                <div style={{ fontSize:20, fontWeight:700, marginBottom:6 }}>{selected.watch_brand||"—"}</div>
                <div style={{ fontSize:14, color:"#ffffff50" }}>In: {selected.received_date}</div>
                <div style={{ fontSize:14, color:"#ffffff50", marginTop:3 }}>Ready: {selected.estimated_ready||"TBC"}</div>
              </div>
              <div style={{ background:"#1a1a2e", borderRadius:12, padding:18 }}>
                <div style={{ fontSize:11, color:"#ffffff40", letterSpacing:"0.08em", marginBottom:10 }}>FINANCIALS</div>
                <div style={{ display:"flex", justifyContent:"space-between", marginBottom:8 }}>
                  <span style={{ color:"#ffffff60", fontSize:14 }}>Cost to Business</span>
                  <span style={{ fontWeight:700 }}>{selected.cost_to_business!=null?`$${selected.cost_to_business}`:"—"}</span>
                </div>
                <div style={{ display:"flex", justifyContent:"space-between" }}>
                  <span style={{ color:"#ffffff60", fontSize:14 }}>Quote to Customer</span>
                  <span style={{ fontWeight:700, color:"#c9a84c" }}>{selected.quote!=null?`$${selected.quote}`:"—"}</span>
                </div>
              </div>
              <div style={{ background:"#1a1a2e", borderRadius:12, padding:18, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", gap:8 }}>
                <div style={{ fontSize:11, color:"#ffffff40", letterSpacing:"0.08em" }}>CUSTOMER QR CODE</div>
                <QRCode id={selected.id} size={100} />
                <button onClick={() => printTicket(selected)} style={{ background:"#c9a84c", color:"#1a1a2e", border:"none", padding:"6px 14px", borderRadius:6, cursor:"pointer", fontWeight:700, fontSize:12 }}>🖨 Print Ticket</button>
              </div>
            </div>

            {selected.issue && (
              <div style={{ background:"#1a1a2e", borderRadius:12, padding:18, marginBottom:16 }}>
                <div style={{ fontSize:11, color:"#ffffff40", letterSpacing:"0.08em", marginBottom:8 }}>WORK BEING DONE</div>
                <div style={{ fontSize:14, color:"#ffffff90", lineHeight:1.7, whiteSpace:"pre-wrap" }}>{selected.issue}</div>
              </div>
            )}

            <div style={{ background:"#1a1a2e", borderRadius:12, padding:18, marginBottom:16 }}>
              <div style={{ fontSize:11, color:"#ffffff40", letterSpacing:"0.08em", marginBottom:12 }}>UPDATE STATUS</div>
              <div style={{ display:"flex", flexWrap:"wrap", gap:6 }}>
                {ALL_STATUSES.map(s => (
                  <button key={s} onClick={() => handleStatusChange(selected.id, s)} style={{ background:selected.status===s?STATUS_CONFIG[s].color:"transparent", border:`1px solid ${STATUS_CONFIG[s].color}`, color:selected.status===s?"#fff":STATUS_CONFIG[s].color, padding:"6px 14px", borderRadius:20, cursor:"pointer", fontSize:13, fontWeight:600 }}>{s}</button>
                ))}
              </div>
            </div>

            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16 }}>
              <div style={{ background:"#1a1a2e", borderRadius:12, padding:18 }}>
                <div style={{ fontSize:11, color:"#ffffff40", letterSpacing:"0.08em", marginBottom:10 }}>REPAIR NOTES</div>
                <div style={{ fontSize:13, color:"#ffffff70", lineHeight:1.7, marginBottom:14, whiteSpace:"pre-wrap", minHeight:36 }}>{selected.notes||"No notes yet."}</div>
                <textarea placeholder="Add a note…" value={noteInput} onChange={e => setNoteInput(e.target.value)} style={{ width:"100%", background:"#0f0f1a", border:"1px solid #ffffff20", color:"#fff", borderRadius:8, padding:10, fontSize:13, minHeight:70, resize:"vertical", boxSizing:"border-box", outline:"none" }} />
                <button onClick={() => handleAddNote(selected.id, noteInput)} style={{ marginTop:8, background:"#c9a84c", color:"#1a1a2e", border:"none", padding:"7px 16px", borderRadius:6, cursor:"pointer", fontWeight:700, fontSize:13 }}>Add Note</button>
              </div>
              <div style={{ background:"#1a1a2e", borderRadius:12, padding:18 }}>
                <div style={{ fontSize:11, color:"#ffffff40", letterSpacing:"0.08em", marginBottom:12 }}>HISTORY</div>
                {(selected.history||[]).slice().reverse().map((h, i) => (
                  <div key={i} style={{ display:"flex", gap:10, marginBottom:10 }}>
                    <div style={{ width:8, height:8, borderRadius:"50%", background:i===0?"#c9a84c":"#ffffff20", marginTop:4, flexShrink:0 }} />
                    <div>
                      <div style={{ fontSize:11, color:"#ffffff30" }}>{h.date}</div>
                      <div style={{ fontSize:13, color:"#ffffff70", marginTop:1 }}>{h.event}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* SCAN */}
        {view === "scan" && (
          <div style={{ padding:"20px 16px", maxWidth:540 }}>
            <h1 style={{ margin:"0 0 8px", fontSize:22 }}>Scan / Lookup</h1>
            <p style={{ color:"#ffffff50", marginBottom:24, fontSize:14 }}>Enter a ticket ID or phone number to find a repair.</p>
            <div style={{ display:"flex", gap:10, marginBottom:20 }}>
              <input placeholder="Ticket ID or phone number…" value={scanInput} onChange={e => { setScanInput(e.target.value); setScanError(false); setScanResult(null); }} onKeyDown={e => e.key==="Enter"&&handleScan()} style={{ flex:1, background:"#1a1a2e", border:"1px solid #ffffff30", color:"#fff", borderRadius:10, padding:"11px 14px", fontSize:15, outline:"none" }} />
              <button onClick={handleScan} style={{ background:"#c9a84c", color:"#1a1a2e", border:"none", padding:"0 20px", borderRadius:10, cursor:"pointer", fontWeight:700, fontSize:14 }}>Find</button>
            </div>
            {scanError && <div style={{ background:"#1a1a2e", border:"1px solid #ef444450", borderRadius:10, padding:16, color:"#ef4444", fontSize:14 }}>No repair found.</div>}
            {scanResult && (
              <div style={{ background:"#1a1a2e", borderRadius:12, padding:20 }}>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:14 }}>
                  <div>
                    <div style={{ color:"#c9a84c", fontSize:14, fontWeight:700 }}>{scanResult.id}</div>
                    <div style={{ fontSize:20, fontWeight:700, marginTop:3 }}>{scanResult.customer_name}</div>
                    <div style={{ color:"#ffffff60", marginTop:3 }}>{scanResult.watch_brand}</div>
                  </div>
                  <StatusBadge status={scanResult.status} />
                </div>
                <div style={{ display:"flex", gap:10 }}>
                  <button onClick={() => { setSelected(scanResult); setView("detail"); }} style={{ flex:1, background:"#c9a84c", color:"#1a1a2e", border:"none", padding:10, borderRadius:8, cursor:"pointer", fontWeight:700 }}>Open Repair</button>
                  <button onClick={() => printTicket(scanResult)} style={{ flex:1, background:"transparent", color:"#fff", border:"1px solid #ffffff30", padding:10, borderRadius:8, cursor:"pointer" }}>🖨 Print</button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* NEW REPAIR */}
        {view === "new" && (
          <NewRepairForm
            inputStyle={inputStyle}
            saving={saving}
            newForm={newForm}
            setNewForm={setNewForm}
            handleNewRepair={handleNewRepair}
            ALL_STATUSES={ALL_STATUSES}
          />
        )}
      </div>

      {/* Mobile bottom nav */}
      <div className="bottom-nav">
        {[{ id:"dashboard", label:"Jobs", icon:"▦" },{ id:"scan", label:"Lookup", icon:"⊙" },{ id:"new", label:"New", icon:"+" }].map(item => (
          <button key={item.id} onClick={() => { setView(item.id); setSelected(null); }}
            style={{ background:"transparent", border:"none", color:view===item.id?"#c9a84c":"#ffffff50", cursor:"pointer", display:"flex", flexDirection:"column", alignItems:"center", gap:4, padding:"4px 24px" }}>
            <span style={{ fontSize:22 }}>{item.icon}</span>
            <span style={{ fontSize:11 }}>{item.label}</span>
          </button>
        ))}
      </div>

    </div>
  );
}
